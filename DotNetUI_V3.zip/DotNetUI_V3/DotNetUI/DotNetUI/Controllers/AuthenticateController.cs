﻿using DotNetUI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace DotNetUI.Controllers
{
    [Authorize(Users = "kiran-vaio\\Kiran")]
    public class AuthenticateController : Controller
    {
        //
        // GET: /Authenticate/

        public ActionResult Login()
        {
            //Session.Abandon();
            //return View();
            return RedirectToAction("Index", "Inventory");
        }
        [HttpPost]
        [AllowAnonymous]
        public ActionResult Login(User user)
        {
            return RedirectToAction("Index", "Inventory");
            //string message = string.Empty;
            //if (ModelState.IsValid)
            //{
            //    InventoryEntities db = new InventoryEntities();
            //    int? userId = db.ValidateUser(user.Username, user.Password).FirstOrDefault();
            //  //  db.Users.Where(m => m.Username == user.Username).Select(x => x.Username).FirstOrDefault();

               
            //    switch (userId.Value)
            //    {
            //        case -1:
            //            message = "Error : Username and/or password is incorrect.";
            //            break;
            //        default:
            //            FormsAuthentication.SetAuthCookie(user.Username, true);
            //            Session["userId"] = userId.ToString();
            //            return RedirectToAction("Index", "Inventory");
            //    }
            //}
            //ViewBag.Message = message;
            //return View(user);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LogOff()
        {
            FormsAuthentication.SignOut();
            Session.Abandon();
            return RedirectToAction("Login", "Authenticate");
        }
    }
}
