﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;

namespace DotNetUI.Controllers
{
    public class Mailers
    {
        public static void SendMail(string ToMail, string FromMail,string pwd,string Subject, string Body)
        {
            using (MailMessage mm = new MailMessage(FromMail, ToMail))
            {
                mm.Subject = Subject;
                mm.Body = Body;
                mm.IsBodyHtml = false;
                using (SmtpClient smtp = new SmtpClient())
                {
                    smtp.Host = "smtp.gmail.com";
                    smtp.EnableSsl = true;
                    NetworkCredential NetworkCred = new NetworkCredential(FromMail, pwd);
                    smtp.UseDefaultCredentials = true;
                    smtp.Credentials = NetworkCred;
                    smtp.Port = 587;
                    smtp.Send(mm);
                 }
            }
        }
    }
}