﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DotNetUI.Models;
using System.Data.OleDb;
using LinqToExcel;
using System.Data.Entity.Validation;
using PagedList;

namespace DotNetUI.Controllers
{
    [Authorize]
    public class InventoryController : Controller
    {
        int pageIndex;
        private InventoryEntities db = new InventoryEntities();

        //
        // GET: /Inventory/

        public ActionResult Index(int? pageNumber, string currentFilter, string searchString)
        {

            
            int pageSize = 5;
            IPagedList<InventoryMaster> invMst = null;
            List<InventoryMaster> InventoryMasters = new List<InventoryMaster>();
            if (!String.IsNullOrEmpty(currentFilter))
                searchString = currentFilter;
            if (!String.IsNullOrEmpty(searchString))
            {
                pageIndex = 1;
                InventoryMasters = db.InventoryMasters.Where(a => a.ServerShortName.Contains(searchString) || a.DBInstance.Contains(searchString) ||  a.Appl.Contains(searchString)).OrderByDescending(b=>b.ID).Except(db.InventoryMasters.Where(a=>(a.DecommissionDate!=null &&  a.ApplicableForBill.ToUpper().Equals("YES"))).AsQueryable()).ToList();
            }
            else
            {


                InventoryMasters = db.InventoryMasters.Except(db.InventoryMasters.Where(a => (a.DecommissionDate != null && a.ApplicableForBill.ToUpper().Equals("YES"))).AsQueryable()).ToList();
            }
            ViewBag.CurrentFilter = searchString;
            pageIndex = pageNumber.HasValue ? Convert.ToInt32(pageNumber) : 1;
            invMst = InventoryMasters.ToPagedList(pageIndex, pageSize);
            return View(invMst);

        }

        public FileResult DownloadExcel()
        {
            string path = "/Doc/Upload/UploadFormat.xlsx";
            return File(path, "application/vnd.ms-excel", "UploadFormat.xlsx");
        }

        public ActionResult Upload()
        {
            return View();
        }

        [HttpPost]
        [HandleError]
        public ActionResult UploadExcel(HttpPostedFileBase FileUpload)
        {

            List<string> data = new List<string>();
            if (FileUpload != null)
            {
                // tdata.ExecuteCommand("truncate table OtherCompanyAssets");  
                if (FileUpload.ContentType == "application/vnd.ms-excel" || FileUpload.ContentType == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                {


                    string filename = FileUpload.FileName;
                    string targetpath = Server.MapPath("~/Doc/");
                    FileUpload.SaveAs(targetpath + filename);
                    string pathToExcelFile = targetpath + filename;
                    string sheetName = "Sheet1";

                    var excelFile = new ExcelQueryFactory(pathToExcelFile);
                    dynamic artistAlbums = excelFile.Worksheet<UploadMaster>(sheetName).ToList();

                    foreach (dynamic a in artistAlbums)
                    {
                        try
                        {

                            InventoryMaster TU = new InventoryMaster();
                            TU.Supportprovider = a.Supportprovider;
                            TU.SupportTeam = a.SupportTeam;
                            TU.SupportClass = a.SupportClass;
                            TU.BusinessUnit = a.BusinessUnit;
                            TU.ServerShortName = a.ServerShortName;
                            TU.DBInstance = a.DBInstance;
                            TU.InstallationType = a.InstallationType;
                            TU.EnvType = a.EnvType;
                            TU.Appl = a.Appl;
                            TU.DbSoftVersion = a.DbSoftVersion;
                            TU.DbSoftPatchLevl = a.DbSoftPatchLevl;
                            TU.TNSNames = a.TNSNames;
                            TU.Port = a.Port;
                            TU.AppTier = a.AppTier;
                            TU.CrossChargeCostCenter = a.CrossChargeCostCenter;
                            TU.CostCenterOwner = a.CostCenterOwner;
                            TU.CrossChargeID = a.CrossChargeID;
                            TU.ScopeStatus = a.ScopeStatus;
                            TU.ApplicableForBill = a.ApplicableForBill;
                            TU.SOX = a.SOX;
                            TU.ITGC = a.ITGC;
                            TU.DiasterRecovery = a.DiasterRecovery;
                            TU.Noteshistory = a.Noteshistory;
                            TU.DecommissionDate = a.DecommissionDate!=null?DateTime.Parse(a.DecommissionDate):null;
                            TU.Modified = a.Modified;
                            TU.ModifiedBy = a.ModifiedBy;
                            TU.Created = Session["userId"].ToString();
                            TU.CreatedBy = User.Identity.Name;
                            TU.BkupMonitor = a.BkupMonitor;
                            TU.OEMDeployed = a.OEMDeployed;
                            TU.OEMTested = a.OEMTested;
                            TU.OSWatcherDeplyed = a.OSWatcherDeplyed;
                            TU.AppContact = a.AppContact;
                            TU.DateOfChangeUpdate = a.DateOfChangeUpdate;
                            TU.Hostname = a.Hostname;
                            TU.Editable = true;
                            db.InventoryMasters.Add(TU);

                            db.SaveChanges();




                        }

                        catch (DbEntityValidationException ex)
                        {
                            foreach (var entityValidationErrors in ex.EntityValidationErrors)
                            {

                                foreach (var validationError in entityValidationErrors.ValidationErrors)
                                {

                                    Response.Write("Property: " + validationError.PropertyName + " Error: " + validationError.ErrorMessage);

                                }

                            }
                        }
                        catch (Exception d)
                        {
                            //data.Add("<ul>");
                            if (!d.ToString().Contains("duplicate key value"))
                                data.Add("Error occurred during file upload");
                            else
                                data.Add("Duplicate record found!");
                            //data.Add("</ul>");
                            data.ToArray();
                            return Json(data, JsonRequestBehavior.AllowGet);
                        }
                    }
                    //deleting excel file from folder  
                    if ((System.IO.File.Exists(pathToExcelFile)))
                    {
                        System.IO.File.Delete(pathToExcelFile);
                    }
                    return RedirectToAction("Index");
                }
                else
                {
                    //alert message for invalid file format  
                    data.Add("<ul>");
                    data.Add("<li>Only Excel file format is allowed</li>");
                    data.Add("</ul>");
                    data.ToArray();
                    return Json(data, JsonRequestBehavior.AllowGet);
                }
            }
            else
            {
                data.Add("<ul>");
                if (FileUpload == null) data.Add("<li>Please choose Excel file</li>");
                data.Add("</ul>");
                data.ToArray();
                return Json(data, JsonRequestBehavior.AllowGet);
            }
        }
        //
        //// GET: /Inventory/Details/5

        //public ActionResult Details(int id = 0)
        //{
        //    InventoryMaster inventorymaster = db.InventoryMasters.Find(id);
        //    if (inventorymaster == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(inventorymaster);
        //}

        ////
        //// GET: /Inventory/Create

        //public ActionResult Create()
        //{
        //    return View();
        //}

        ////
        //// GET: /Inventory/Create

      

        ////
        //// POST: /Inventory/Create

        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult Create(InventoryMaster inventorymaster)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.InventoryMasters.Add(inventorymaster);
        //        db.SaveChanges();
        //        return RedirectToAction("Index");
        //    }

        //    return View(inventorymaster);
        //}

        //
        // GET: /Inventory/Edit/5

        public ActionResult Edit(int id = 0)
        {
            InventoryMaster inventorymaster = db.InventoryMasters.Find(id);
            if (inventorymaster == null)
            {
                return HttpNotFound();
            }
            
            return View(inventorymaster);
        }

        //
        // POST: /Inventory/Edit/5

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Exclude = "ModifiedBy,Modified,Created,CreatedBy")]InventoryMaster inventorymaster)
        {
            if (ModelState.IsValid)
            {
                inventorymaster.Editable = true;
                inventorymaster.Modified=Session["userId"].ToString();
                inventorymaster.ModifiedBy = User.Identity.Name;
                db.Entry(inventorymaster).State = EntityState.Modified;
                db.SaveChanges();
               // Mailers.SendMail("kiransaid23@yahoo.com", "kiransaid23@gmail.com", "********", "Record Modified", "Record has been updated successfully for invetory id " + inventorymaster.ID);
                return RedirectToAction("Index");
            }
            return View(inventorymaster);
        }

        //
        // GET: /Inventory/Delete/5

        public ActionResult Delete(int id = 0)
        {
            InventoryMaster inventorymaster = db.InventoryMasters.Find(id);
            if (inventorymaster == null)
            {
                return HttpNotFound();
            }
            return View(inventorymaster);
        }

        //
        // POST: /Inventory/Delete/5

        public ActionResult Cancel(int id = 0)
        {
            InventoryMaster inventorymaster = db.InventoryMasters.Find(id);
            if (inventorymaster == null)
            {
                return HttpNotFound();
            }
            else
            {
                inventorymaster.Editable = false;
                db.SaveChanges();
            }
            return RedirectToAction("Index"); ;
        }

        

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            InventoryMaster inventorymaster = db.InventoryMasters.Find(id);
            db.InventoryMasters.Remove(inventorymaster);
            db.SaveChanges();
            //Mailers.SendMail("kiransaid23@yahoo.com", "kiransaid23@gmail.com", "********", "Record Deleted", "Record has been deleted successfully for invetory id " + id);
            return RedirectToAction("Index");
        }


        public ActionResult DecommissionList(int? pageNumber, string currentFilter, string searchString)
        {

            
            int pageSize = 5;
            IPagedList<InventoryMaster> invMst = null;
            List<InventoryMaster> InventoryMasters = new List<InventoryMaster>();
            if (!String.IsNullOrEmpty(currentFilter))
                searchString = currentFilter;
            if (!String.IsNullOrEmpty(searchString))
            {
                pageIndex = 1;
                InventoryMasters = db.InventoryMasters.Where(a => (a.ServerShortName.Contains(searchString) || a.DBInstance.Contains(searchString) || a.Appl.Contains(searchString)) && (a.DecommissionDate != null && a.ApplicableForBill.ToUpper().Equals("YES"))).OrderByDescending(b => b.ID).ToList();
            }
            else
            {


                InventoryMasters = db.InventoryMasters.Where(a=>(a.DecommissionDate!=null &&  a.ApplicableForBill.ToUpper().Equals("YES"))).ToList();
            }
            ViewBag.CurrentFilter = searchString;
            pageIndex = pageNumber.HasValue ? Convert.ToInt32(pageNumber) : 1;
            invMst = InventoryMasters.ToPagedList(pageIndex, pageSize);
            return View(invMst);

        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}